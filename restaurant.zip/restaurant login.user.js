// ==UserScript==
// @name         restaurant login
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://grestaurant.kcislk.ntpc.edu.tw/
// @grant        none
// ==/UserScript==
(function() {
    'use strict';

    document.querySelector("input#acc").value = "學號"
    document.querySelector("input#pwd").value = "身分證"

    function anchorclick(node)
{
    var evt = document.createEvent("MouseEvents");
    evt.initMouseEvent("click", true, true, window,
                       0, 0, 0, 0, 0, false, false, false, false, 0, null);
    var allowDefault = node.dispatchEvent(evt);
}

function xpath(query) {
    return document.evaluate(query, document, null,
                             XPathResult.UNORDERED_NODE_SNAPSHOT_TYPE, null);
}
var btnlTags =xpath("//input[@name='sub']");
if ( btnlTags.snapshotLength > 0)
{
    var thisDiv =btnlTags.snapshotItem(0);
    anchorclick(thisDiv);
}
})();


