// ==UserScript==
// @name         close return tab
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @include      http://grestaurant.kcislk.ntpc.edu.tw/CheckOrder.aspx?retn=*
// @grant        window.close
// ==/UserScript==

(function() {
    'use strict';
    setInterval(function(){
            window.close();
    }, 1000);
})();